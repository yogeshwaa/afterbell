import { currentAndNext } from './calendar.js';
async function update() {
  const { events = [] } = await chrome.storage.local.get('events');
  const { current } = currentAndNext(events);
  const e = current[0];
  await chrome.action.setBadgeBackgroundColor({ color: '#14695e' });
  await chrome.action.setBadgeText({ text: e ? String(Math.ceil((e.end - Date.now()) / 60000)) : '' });
  await chrome.action.setTitle({ title: e ? `${e.title} · ${e.room} · ${e.teacher} · ${Math.ceil((e.end - Date.now()) / 60000)} min left` : 'Afterbell — open your timetable' });
}
async function setup() { await chrome.alarms.create('clock', { periodInMinutes: 1 }); await update(); }
chrome.runtime.onInstalled.addListener(setup);
chrome.runtime.onStartup.addListener(setup);
chrome.alarms.onAlarm.addListener(a => { if (a.name === 'clock') update(); });
chrome.storage.onChanged.addListener(update);
setup();
