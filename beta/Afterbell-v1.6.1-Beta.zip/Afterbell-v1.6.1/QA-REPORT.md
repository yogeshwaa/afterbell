# Afterbell v1.6.1 — Regression results

**172 checks passed:** 137 real-extension browser checks, 12 lifecycle/concurrency checks, and 23 strict calendar cases. No uncaught browser exceptions were observed. The original 1,039-class Sentral sample also passes the existing parser regression checks.

Environment: Windows, Playwright Chromium 156.0.8078.4. The extension was loaded as a real Manifest V3 extension in an isolated browser profile. Real extension storage, alarms, action badges, toolbar popup, tab creation and fullscreen-window APIs were exercised. The browser test runtime is not part of the extension.

## Fixes

- Open-in-tab buttons appear only in the actual toolbar popup, including correct detection of tabs opened without a query string.
- Every select and option follows the chosen interface font, including school time zone. All 14 choices were checked and the six bundled font families were loaded.
- Restored system reduced-motion support for animated backgrounds.
- Added explicit Escape handling for page fullscreen, plus a fullscreen initialization fix for newly created windows.
- Invalid calendar dates and nested event blocks are rejected; alarm descriptions cannot overwrite class details.
- Cancelled or superseded delayed imports cannot return later. Reset/Cancel also invalidate pending background uploads.
- Image and video uploads are decoded before being accepted. Corrupt media is rejected.
- Today's date follows school-time midnight while manually selected dates stay selected. Daily timetable grouping is cached to avoid reparsing every class on each tick.

## Coverage

Themes, all six clock styles, both font selectors, time formats, colon dots, size and colour controls, visibility toggles, built-in backgrounds, reduced motion, PNG/JPEG/WebP/GIF/MP4/WebM uploads, mute/loop/pause/resume, oversize/unsupported/corrupt files, imports, cancellation, reset and removal, real quota failures, Apply retry, all time zones, start/end boundaries, empty/ended state, midnight, popup/tab/fullscreen navigation, onboarding/help/images, responsive widths (375/430/900/1440px), HTML injection resistance, and local asset loading. Lifecycle tests cover browser restart, saved media/timetable, alarm restoration, concurrent saves and delayed-operation cancellation.

Calendar tests cover UTC and school time zones, daylight saving, leap years, invalid dates/times, missing fields, escaped/folded text, cancellation, overlapping classes, nested alarms, unsupported recurrence and the supplied sample. Recurring/all-day calendars remain deliberately unsupported and return an explanation.

These results describe the tested browser and fixtures; they are not a guarantee against every possible bug or a cross-platform certification. Native menu rendering and media codecs can vary by browser/OS.

## Browser check list

- PASS: Real extension service worker loaded
- PASS: New user sees welcome
- PASS: Tab detected without URL query
- PASS: Header tab button hidden
- PASS: Get started opens Help
- PASS: Censored help image 1 decodes
- PASS: Censored help image 2 decodes
- PASS: Censored help image 3 decodes
- PASS: Help points to import
- PASS: Display tab button hidden
- PASS: Helvetica default
- PASS: Every dropdown/option follows helvetica
- PASS: Countdown font helvetica previews
- PASS: Every dropdown/option follows ui
- PASS: Countdown font ui previews
- PASS: Every dropdown/option follows doto
- PASS: Countdown font doto previews
- PASS: Every dropdown/option follows space
- PASS: Countdown font space previews
- PASS: Every dropdown/option follows jetbrains
- PASS: Countdown font jetbrains previews
- PASS: Every dropdown/option follows orbitron
- PASS: Countdown font orbitron previews
- PASS: Every dropdown/option follows lora
- PASS: Countdown font lora previews
- PASS: Every dropdown/option follows vt323
- PASS: Countdown font vt323 previews
- PASS: Every dropdown/option follows arial
- PASS: Countdown font arial previews
- PASS: Every dropdown/option follows georgia
- PASS: Countdown font georgia previews
- PASS: Every dropdown/option follows courier
- PASS: Countdown font courier previews
- PASS: Every dropdown/option follows consolas
- PASS: Countdown font consolas previews
- PASS: Every dropdown/option follows trebutchet
- PASS: Countdown font trebutchet previews
- PASS: Every dropdown/option follows times
- PASS: Countdown font times previews
- PASS: Font changes did not save
- PASS: Bundled font Doto loads
- PASS: Bundled font SpaceGrotesk loads
- PASS: Bundled font JetBrainsMono loads
- PASS: Bundled font Orbitron loads
- PASS: Bundled font Lora loads
- PASS: Bundled font VT323 loads
- PASS: Invalid import preserved empty storage
- PASS: Import preview has room/teacher
- PASS: Import not saved before Apply
- PASS: Applied timetable stored
- PASS: Successful onboarding does not repeat
- PASS: Real toolbar badge minutes
- PASS: Real toolbar tooltip details
- PASS: Real minute alarm
- PASS: Theme light
- PASS: Theme dark
- PASS: Theme system
- PASS: Theme forest
- PASS: Theme rose
- PASS: Theme cyberpunk
- PASS: Theme custom
- PASS: Clock minimal
- PASS: Clock pie
- PASS: Clock ring
- PASS: Clock analog
- PASS: Analogue numerals and hands
- PASS: Clock digital
- PASS: Clock cyberpunk
- PASS: Colon uses two CSS dots
- PASS: Total minutes
- PASS: Total seconds
- PASS: Visibility showTeacher
- PASS: Visibility showPeriod
- PASS: Visibility showProgress
- PASS: Visibility showSchedule
- PASS: Size slider
- PASS: Custom colour activates custom theme
- PASS: Background plain
- PASS: Background aurora
- PASS: Background grid
- PASS: Background stars
- PASS: Animation disabled
- PASS: Reduced motion respected
- PASS: Cancel restores saved theme
- PASS: Corrupt media rejected
- PASS: Image draft not saved
- PASS: Background saved
- PASS: Remove upload is preview-only
- PASS: Cancel restores background
- PASS: Upload image/gif decodes
- PASS: Upload image/jpeg decodes
- PASS: Upload image/webp decodes
- PASS: Real WebM metadata loads
- PASS: Video muted and looping
- PASS: Video pauses with motion off
- PASS: Video resumes
- PASS: Real MP4 background loads
- PASS: Oversized wallpaper rejected
- PASS: Unsupported wallpaper rejected
- PASS: Corrupt video rejected
- PASS: Actual storage-quota failure leaves saved media intact
- PASS: Failed save leaves draft retryable
- PASS: Reset preview only
- PASS: Removal preview only
- PASS: Zone preview only
- PASS: Timezone Australia/Sydney previews
- PASS: Timezone Australia/Brisbane previews
- PASS: Timezone Australia/Melbourne previews
- PASS: Timezone Australia/Adelaide previews
- PASS: Timezone Australia/Perth previews
- PASS: Timezone Australia/Darwin previews
- PASS: Timezone Australia/Hobart previews
- PASS: Timezone Australia/Lord_Howe previews
- PASS: Timezone Pacific/Auckland previews
- PASS: Timezone UTC previews
- PASS: Oversized ICS rejected
- PASS: Calendar text cannot inject HTML
- PASS: Class starts at inclusive boundary
- PASS: Adjacent class starts at exact end
- PASS: Ended timetable state
- PASS: Today date rolls over at school midnight
- PASS: Manually browsed date preserved across midnight
- PASS: Real page fullscreen enters
- PASS: Real page fullscreen exits
- PASS: Style preview labelled
- PASS: Style preview exits
- PASS: No horizontal overflow 1440
- PASS: No horizontal overflow 900
- PASS: No horizontal overflow 430
- PASS: No horizontal overflow 375
- PASS: Real toolbar popup keeps tab button
- PASS: Popup opens actual extension tab
- PASS: New tab removes redundant button
- PASS: Popup opens real fullscreen window
- PASS: Fullscreen window has no redundant tab button
- PASS: Fullscreen window exits via control
- PASS: No uncaught browser exceptions
- PASS: Timetable survives browser restart
- PASS: Saved wallpaper survives restart
- PASS: Alarm restored on restart
- PASS: Cancel prevents delayed import returning
- PASS: Reset cancels delayed image preview
- PASS: Concurrent save commits captured revision
- PASS: Newer edit stays visibly pending
- PASS: Cancel restores last successful revision
- PASS: Applied timetable removal persists
- PASS: Getting started can be replayed
- PASS: Explore first opens empty dashboard
- PASS: Explore preference persists
