import { parseICS, currentAndNext, dayKey } from './calendar.js';
import { defaults, fonts, remainingText, clockState } from './appearance.js';
import { updateIcons } from './icons.js';
let appearance = { ...defaults }, preview = false, previewTime = 0;
const $ = id => document.getElementById(id);
let onboardingDismissed = false;
let saved = null, wallpaper = null, saving = false, mediaRevision = 0;
let importRevision = 0, lastToday = '', tabView = false;
let dayCache = { events: null, zone: '', days: new Map() };
let events = [], zone = 'Australia/Sydney', fileName = '';
const time = t => new Intl.DateTimeFormat('en-AU', { timeZone: zone, hour: 'numeric', minute: '2-digit' }).format(t);
const date = t => new Intl.DateTimeFormat('en-AU', { timeZone: zone, weekday: 'long', day: 'numeric', month: 'long' }).format(t);
function node(tag, text, cls) {
  const el = document.createElement(tag);
  if (tag !== 'option' && text.includes('.')) text.split('.').forEach((part,i)=>{
    if(i){const dot=document.createElement('span');dot.className='normal-period';dot.textContent='.';el.append(dot);}
    el.append(document.createTextNode(part));
  }); else el.textContent = text;
  if (cls) el.className = cls; return el;
}
function setTimerText(element, text) {
  element.replaceChildren();
  text.split(':').forEach((part, index) => {
    if (index) {
      const separator = node('span', '', 'time-separator');
      separator.append(node('span', ':', 'separator-text'));
      element.append(separator);
    }
    element.append(document.createTextNode(part));
  });
}
function countdown(ms) { const s = Math.max(0, Math.ceil(ms / 1000)); return `${Math.floor(s / 3600) ? Math.floor(s / 3600) + ':' : ''}${String(Math.floor(s / 60) % 60).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`; }
function card(e, active, now) {
  const box = node('div', '', 'hero');
  box.append(node('div', active ? 'IN CLASS NOW' : 'UP NEXT', 'eyebrow'), node('h2', e.title));
  const state = clockState(e, active, now, zone);
  box.dataset.clock = appearance.clockStyle;
  if (['pie', 'ring', 'analog'].includes(appearance.clockStyle)) {
    const dial = node('div', '', 'dial ' + appearance.clockStyle);
    dial.setAttribute('role', 'img');
    dial.setAttribute('aria-label', appearance.clockStyle === 'analog' ? 'Current school time: ' + time(now) : active ? Math.ceil(state.fraction * 100) + '% of class remaining' : 'Next class has not started');
    dial.style.setProperty('--remaining', (state.fraction ?? 0) * 360 + 'deg');
    if (appearance.clockStyle === 'analog') {
      for (let i = 1; i <= 12; i++) { const tick = node('span', String(i), 'numeral'); tick.style.left = (50 + 40 * Math.sin(i * Math.PI / 6)) + '%'; tick.style.top = (50 - 40 * Math.cos(i * Math.PI / 6)) + '%'; dial.append(tick); }
      for (const hand of ['hour','minute','second']) { const el = node('i', '', 'hand ' + hand); el.style.transform = 'rotate(' + state[hand] + 'deg)'; dial.append(el); }
      dial.append(node('b', '', 'hub'));
    } else dial.append(node('span', active ? Math.ceil(state.fraction * 100) + '%' : 'NEXT', 'dial-label'));
    box.append(dial);
    if (appearance.clockStyle === 'analog') box.append(node('p', 'School time · ' + time(now), 'meta'));
  }
  const duration = node('div', '', 'count');
  setTimerText(duration, remainingText(state.remaining, appearance.units));
  duration.append(node('small', active ? 'remaining' : 'until class')); box.append(duration);
  box.append(node('p', `${time(e.start)} – ${time(e.end)}${dayKey(e.start, zone) !== dayKey(now, zone) ? ' · ' + date(e.start) : ''}`));
  box.append(node('div', [e.room, appearance.showTeacher ? e.teacher : ''].filter(Boolean).join(' · '), 'meta'));
  if (e.period && appearance.showPeriod) box.append(node('p', `Period ${e.period}`, 'meta'));
  if (active && appearance.showProgress) { const p = document.createElement('progress'); p.max = e.end - e.start; p.value = now - e.start; p.setAttribute('aria-label', 'Class progress'); box.append(p); }
  return box;
}
function render() {
  const now = Date.now();
  const today = dayKey(now, zone);
  if (lastToday && $('date').value === lastToday) $('date').value = today;
  lastToday = today;
  const welcomeVisible = !events.length && !onboardingDismissed && !preview;
  $('welcome').hidden = !welcomeVisible;
  document.querySelector('.dashboard').hidden = welcomeVisible;
  $('setupBanner').hidden = events.length > 0;
  $('importShortcut').classList.toggle('needs-import', !events.length);
  $('today').textContent = date(now); $('zoneLabel').textContent = zone;
  const demo = { title: 'Preview · Design and Technology', room: 'M3.10', teacher: 'Example teacher', period: '1', start: previewTime - 18 * 60000, end: previewTime + 36 * 60000 };
  const { current, next } = preview ? { current: [demo] } : currentAndNext(events, now);
  $('live').replaceChildren();
  if (current.length) { for (const e of current) $('live').append(card(e, true, now)); }
  else if (next) $('live').append(card(next, false, now));
  else $('live').append(node('div', events.length ? 'Your timetable has ended. Import a fresh Sentral export to keep tracking.' : 'Your day, on your terms. Open Settings to import your Sentral timetable.', 'empty'));
  const sample = current[0] || next || { ...demo, title: 'Example class', start: now - 18*60000, end: now + 36*60000 };
  $('draftPreview').replaceChildren(card(sample, sample.start <= now && sample.end > now, now));
  $('classes').replaceChildren();
  if (dayCache.events !== events || dayCache.zone !== zone) {
    const days = new Map();
    for (const e of events) {
      const key = dayKey(e.start, zone);
      if (!days.has(key)) days.set(key, []);
      days.get(key).push(e);
    }
    dayCache = { events, zone, days };
  }
  const selected = dayCache.days.get($('date').value) || [];
  for (const e of selected) {
    const active = e.start <= now && now < e.end;
    const row = node('div', '', 'class' + (active ? ' active' : ''));
    const times = node('div', time(e.start), 'times'); times.append(node('span', time(e.end)));
    const content = node('div', ''); const title = node('div', e.title, 'subject');
    if (active) title.append(node('span', 'NOW', 'pill'));
    content.append(title, node('div', [e.room, appearance.showTeacher ? e.teacher : ''].filter(Boolean).join(' · '), 'detail'), node('div', [e.period && appearance.showPeriod ? 'Period ' + e.period : '', e.code].filter(Boolean).join(' · '), 'detail'));
    row.append(times, content); $('classes').append(row);
  }
  if (!selected.length) $('classes').append(node('p', 'No classes scheduled for this date.', 'empty'));
}
$('file').addEventListener('change', async ev => {
  const file = ev.target.files[0]; if (!file) return;
  const revision = ++importRevision;
  try {
    if (file.size > 8 * 1024 * 1024) throw new Error('Please choose an .ics file smaller than 8 MB.');
    const parsed = parseICS(await file.text());
    if (revision !== importRevision) return;
    events = parsed; fileName = file.name; onboardingDismissed = true; preview = false; $('preview').textContent = 'Preview styles';
    $('source').textContent = `${fileName} · ${events.length} classes · ${date(events[0].start)} to ${date(events.at(-1).start)}`;
    $('message').textContent = `Preview ready: ${events.length} classes. Apply changes to save this timetable.`; render(); updateDraft();
  } catch (err) { if (revision === importRevision) $('message').textContent = err.message; }
  ev.target.value = '';
});
$('date').addEventListener('change', render);
$('zone').addEventListener('change', () => { zone = $('zone').value; $('date').value = dayKey(Date.now(), zone); render(); updateDraft(); });
function openTab() { return chrome.tabs.create({ url: chrome.runtime.getURL('popup.html?view=tab') }); }
$('expand').addEventListener('click', openTab);
$('openTab').addEventListener('click', openTab);
$('fullscreen').addEventListener('click', async () => {
  try {
    const view = new URLSearchParams(location.search).get('view');
    if (view === 'window') {
      const win = await chrome.windows.getCurrent();
      const state = win.state === 'fullscreen' ? 'normal' : 'fullscreen';
      await chrome.windows.update(win.id, { state });
      $('fullscreen').textContent = state === 'fullscreen' ? 'Exit fullscreen ⛶' : 'Enter fullscreen ⛶';
      updateIcons(appearance.dotIcons);
      $('settingsPanel').close();
    } else if (tabView) {
      $('settingsPanel').close();
      if (document.fullscreenElement) await document.exitFullscreen();
      else await document.documentElement.requestFullscreen();
    } else await chrome.windows.create({url:chrome.runtime.getURL('popup.html?view=window'),type:'normal',state:'fullscreen'});
  } catch (err) { $('displayMessage').textContent = 'Could not enter fullscreen. Open Afterbell in a tab and use the fullscreen button there, or press F11.'; }
});
document.addEventListener('fullscreenchange', () => { $('fullscreen').textContent = document.fullscreenElement ? 'Exit fullscreen' : 'Enter fullscreen'; updateIcons(appearance.dotIcons); });
document.addEventListener('keydown', event => {
  if (event.key === 'Escape' && document.fullscreenElement && !$('settingsPanel').open) {
    document.exitFullscreen().catch(() => {});
  }
});
function showSection(id) {
  if (!$('settingsPanel').open) $('settingsPanel').showModal();
  for (const section of ['appearance','settings','display','help']) $(section).open = section === id;
  document.querySelectorAll('[data-section]').forEach(b => b.setAttribute('aria-pressed', String(b.dataset.section === id)));
  $(id).scrollIntoView({block:'start'});
}
function showImport() { showSection('settings'); $('file').focus({preventScroll:true}); }
for (const id of ['helpShortcut','getStarted','setupGuide']) $(id).addEventListener('click', () => showSection('help'));
for (const id of ['goImport','haveFile','importShortcut','setupImport']) $(id).addEventListener('click', showImport);
document.querySelectorAll('[data-section]').forEach(b => b.addEventListener('click', () => showSection(b.dataset.section)));
$('skipWelcome').addEventListener('click', async () => { onboardingDismissed = true; if (saved) saved.onboardingDismissed = true; render(); await chrome.storage.local.set({ onboardingDismissed:true }); });
$('replayWelcome').addEventListener('click', async () => { if (events.length) { showSection('help'); return; } onboardingDismissed = false; if (saved) saved.onboardingDismissed = false; preview = false; $('settingsPanel').close(); render(); await chrome.storage.local.set({ onboardingDismissed:false }); });
$('clear').addEventListener('click', () => { importRevision++; events = []; fileName = ''; $('source').textContent = ''; $('message').textContent = 'Previewing removal. Apply changes to remove your saved timetable.'; render(); updateDraft(); });
async function init() {
  // getCurrent distinguishes an actual extension tab from the toolbar popup,
  // including tabs opened directly without our optional query string.
  if (chrome.tabs.getCurrent) {
    try { tabView = !!(await chrome.tabs.getCurrent()); } catch { /* keep URL fallback */ }
  }
  updateViewControls();
  const data = await chrome.storage.local.get(['events', 'zone', 'fileName', 'appearance', 'wallpaper', 'onboardingDismissed', 'introOpened']);
  if (!tabView && !data.events?.length && !data.onboardingDismissed && !data.introOpened) {
    await chrome.tabs.create({ url: chrome.runtime.getURL('popup.html?view=tab&intro=1') });
    await chrome.storage.local.set({ introOpened: true });
    window.close();
    return;
  }
  if (tabView && !data.introOpened && !data.events?.length && !data.onboardingDismissed) {
    await chrome.storage.local.set({ introOpened: true });
  }
  onboardingDismissed = !!data.onboardingDismissed;
  appearance = { ...defaults, ...data.appearance };
  for (const id of ['bodyFont','timerFont']) { for (const [key,[label]] of Object.entries(fonts)) { const option = node('option',label); option.value = key; $(id).append(option); } }
  wallpaper = data.wallpaper || null;
  syncControls(); setWallpaper(wallpaper);
  events = data.events || []; zone = data.zone || zone; fileName = data.fileName || '';
  $('zone').value = zone; $('date').value = dayKey(Date.now(), zone);
  $('source').textContent = events.length ? `${fileName} · ${events.length} classes · ${date(events[0].start)} to ${date(events.at(-1).start)}` : '';
  saved = snapshot();
  $('settings').open = !events.length; render(); updateDraft(); setInterval(render, 1000);
  // Some browser builds restore normal bounds while a new window is loading.
  // Reapply fullscreen after its extension page has finished initializing.
  if (new URLSearchParams(location.search).get('view') === 'window') {
    const win = await chrome.windows.getCurrent();
    if (win.state !== 'fullscreen') await chrome.windows.update(win.id, { state: 'fullscreen' });
  }
  document.body.dataset.ready = 'true';
}
function syncControls() {
  for (const key of Object.keys(defaults)) { const el = $(key); if (el.type === 'checkbox') el.checked = appearance[key]; else el.value = appearance[key]; }
}
function applyAppearance() {
  updateIcons(appearance.dotIcons);
  document.body.dataset.theme = appearance.theme;
  document.body.dataset.background = appearance.background;
  document.body.classList.toggle('no-motion', !appearance.motion);
  const style = document.body.style;
  style.setProperty('--body-font', (fonts[appearance.bodyFont] || fonts.ui)[1]);
  style.setProperty('--timer-font', (fonts[appearance.timerFont] || fonts.doto)[1]);
  $('fontSample').style.fontFamily = (fonts[appearance.bodyFont] || fonts.ui)[1];
  $('timerSample').style.fontFamily = (fonts[appearance.timerFont] || fonts.doto)[1];
  setTimerText($('timerSample'), '36:00');
  style.setProperty('--accent-custom', appearance.accent); style.setProperty('--base-custom', appearance.base); style.setProperty('--ink-custom', appearance.ink);
  style.setProperty('--timer-scale', appearance.scale / 100); style.setProperty('--dim', appearance.dim / 100);
  document.querySelector('.schedule').hidden = !appearance.showSchedule;
  const video = $('wallpaper');
  if (appearance.motion && appearance.background === 'upload') video.play().catch(() => {}); else video.pause();
}
function snapshot() { return { appearance: {...appearance}, wallpaper, events, fileName, zone, onboardingDismissed }; }
function isDirty() { return !!saved && (JSON.stringify(appearance) !== JSON.stringify(saved.appearance) || wallpaper !== saved.wallpaper || events !== saved.events || fileName !== saved.fileName || zone !== saved.zone); }
function updateDraft() {
  const dirty = isDirty();
  $('changesBar').hidden = !dirty;
  $('commitStatus').textContent = saving ? 'Applying…' : dirty ? 'Previewing · not saved yet' : 'All changes applied';
  for (const id of ['applySettings','cancelSettings','applyDraft','revertDraft']) $(id).disabled = saving || !dirty;
  updateIcons(appearance.dotIcons);
}
async function commitDraft() {
  if (saving || !isDirty()) return;
  saving = true; updateDraft();
  // Capture one revision: newer edits remain a draft if they arrive while saving.
  const next = snapshot();
  try {
    await chrome.storage.local.set(next);
    saved = next;
    $('appearanceMessage').textContent = 'Changes applied.';
    $('message').textContent = events.length ? 'Timetable saved.' : 'No timetable saved.';
  } catch (err) { $('appearanceMessage').textContent = 'Could not apply changes. Your saved settings are unchanged. Try a smaller background.'; }
  finally { saving = false; updateDraft(); }
}
function cancelDraft() {
  if (!saved || saving) return;
  mediaRevision++;
  importRevision++;
  appearance = {...saved.appearance}; wallpaper = saved.wallpaper; events = saved.events; fileName = saved.fileName; zone = saved.zone; onboardingDismissed = saved.onboardingDismissed;
  preview = false; $('preview').textContent = 'Preview styles';
  $('zone').value = zone; $('date').value = dayKey(Date.now(), zone);
  $('source').textContent = fileName ? fileName + ' · ' + events.length + ' classes' : '';
  syncControls(); setWallpaper(wallpaper); render(); updateDraft();
  $('appearanceMessage').textContent = 'Unapplied changes discarded.'; $('message').textContent = '';
}
for (const id of ['applySettings','applyDraft']) $(id).addEventListener('click', commitDraft);
for (const id of ['cancelSettings','revertDraft']) $(id).addEventListener('click', cancelDraft);
for (const key of Object.keys(defaults)) $(key).addEventListener('input', () => {
  const el = $(key); appearance[key] = el.type === 'checkbox' ? el.checked : el.type === 'range' ? +el.value : el.value;
  if (['accent','base','ink'].includes(key)) { appearance.theme = 'custom'; $('theme').value = 'custom'; }
  applyAppearance(); render(); updateDraft();
});
function setWallpaper(media) {
  $('wallpaper').removeAttribute('src'); $('backdrop').style.backgroundImage = '';
  if (!media) { applyAppearance(); return; }
  if (media.type.startsWith('video/')) { $('wallpaper').src = media.url; $('wallpaper').muted = true; }
  else $('backdrop').style.backgroundImage = 'url("' + media.url + '")';
  applyAppearance();
}
async function validateMedia(media) {
  if (media.type.startsWith('image/')) {
    const image = new Image(); image.src = media.url;
    try { await image.decode(); } catch { throw Error('This image could not be opened. Choose a valid image file.'); }
    return;
  }
  const video = document.createElement('video'); video.preload = 'metadata';
  try {
    await new Promise((resolve, reject) => {
      const timeout = setTimeout(() => reject(Error('Video preview timed out. Try a smaller MP4 or WebM.')), 10000);
      video.onloadedmetadata = () => { clearTimeout(timeout); resolve(); };
      video.onerror = () => { clearTimeout(timeout); reject(Error('This video could not be opened. Try another MP4 or WebM.')); };
      video.src = media.url;
    });
  } finally { video.removeAttribute('src'); video.load(); }
}
$('media').addEventListener('change', async event => {
  const file = event.target.files[0]; if (!file) return;
  const revision = ++mediaRevision;
  try {
    if (!['image/png','image/jpeg','image/gif','image/webp','video/mp4','video/webm'].includes(file.type)) throw Error('Choose a PNG, JPG, WebP, GIF, MP4 or WebM file.');
    if (file.size > 3 * 1024 * 1024) throw Error('Choose a background smaller than 3 MB.');
    const url = await new Promise((resolve, reject) => { const r = new FileReader(); r.onload = () => resolve(r.result); r.onerror = reject; r.readAsDataURL(file); });
    const media = { type: file.type, url };
    await validateMedia(media);
    if (revision !== mediaRevision) return;
    wallpaper = media; appearance.background = 'upload'; syncControls(); setWallpaper(media); render(); updateDraft();
    $('appearanceMessage').textContent = 'Background preview ready. Apply changes to save.';
  } catch (err) { $('appearanceMessage').textContent = err.message || 'Could not save background.'; }
  event.target.value = '';
});
$('removeBackground').addEventListener('click', () => { mediaRevision++; wallpaper = null; appearance.background = 'plain'; syncControls(); setWallpaper(null); render(); updateDraft(); });
$('resetAppearance').addEventListener('click', () => { mediaRevision++; appearance = { ...defaults }; syncControls(); applyAppearance(); render(); updateDraft(); });
$('preview').addEventListener('click', () => { preview = !preview; previewTime = Date.now(); $('preview').textContent = preview ? 'Exit preview' : 'Preview styles'; updateIcons(appearance.dotIcons); if (preview) $('settingsPanel').close(); $('appearanceMessage').textContent = preview ? 'Example class preview — your timetable is unchanged.' : ''; render(); });
$('openSettings').addEventListener('click', () => showSection('appearance'));
$('closeSettings').addEventListener('click', () => $('settingsPanel').close());
$('settingsPanel').addEventListener('click', event => { if (event.target === $('settingsPanel')) { const r = event.target.getBoundingClientRect(); if (event.clientX < r.left || event.clientX > r.right || event.clientY < r.top || event.clientY > r.bottom) event.target.close(); } });
function updateViewControls() {
  document.body.classList.toggle('tab-view', tabView);
  $('expand').hidden = tabView;
  $('openTab').hidden = tabView;
  if (new URLSearchParams(location.search).get('view') === 'window') $('fullscreen').textContent = 'Exit fullscreen ⛶';
  updateIcons(appearance.dotIcons);
}
document.querySelectorAll('.settings-content details').forEach(el=>el.addEventListener('toggle',()=>updateIcons(appearance.dotIcons)));
tabView = new URLSearchParams(location.search).has('view');
updateViewControls();
init().catch(err => { $('message').textContent = 'Could not load timetable: ' + err.message; $('settings').open = true; $('settingsPanel').showModal(); });
