# Afterbell v1.7.0 — Verification

192 checks passed: 137 + 12 + 13 + 7 + 23 across real-extension regression, lifecycle/concurrency, icons/punctuation, first-run introduction, and calendar suites. No uncaught browser exceptions were observed in the main regression suite.

Verified in isolated Windows Chromium 156.0.8078.4. The tests exercise real extension storage, toolbar popup, badges, alarms, tab/window creation and fullscreen APIs.

## New behavior

- A fresh install opens the full-tab welcome page automatically. A first toolbar launch redirects there if it has not been shown. Browser restart does not repeat onboarding.
- Welcome action: “I've downloaded my timetable”; step one: “Download timetable”. Detailed instructions still explain the ICS export format.
- Welcome heading and generated class text use normal periods.
- Dot-matrix icons are enabled by default. Turning them off previews clean outline icons. Apply saves the preference; Cancel restores it. Header controls, welcome/import graphics, action buttons, disclosures, dropdown chevrons and calendar picker share the style. Applying updates the Chrome toolbar icon. Chrome's extension-management listing retains the packaged brand icon.

## Regression coverage

Themes, all countdown styles, 14 font options and dropdown font matching, time formats, colon rendering, size/colour/visibility settings, backgrounds, reduced motion, PNG/JPEG/WebP/GIF/MP4/WebM decoding, corrupt/unsupported/oversize files, imports, Apply/Cancel, removals, reset, real storage-quota failure, time zones, exact class boundaries, midnight rollover, popup/tab/fullscreen navigation, help images, responsive layouts, browser restart and delayed-operation cancellation.

Calendar cases cover daylight saving, leap dates, invalid dates/times, nested alarms, overlaps, cancellation, folded/escaped text, missing fields and the 1,039-class sample. Recurring/all-day calendars remain unsupported with an explanatory error.

Results apply to the tested browser and fixtures, rather than guaranteeing every browser/OS combination or the absence of all bugs.
