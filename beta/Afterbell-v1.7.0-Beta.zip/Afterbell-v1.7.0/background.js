import { currentAndNext } from './calendar.js';
async function update() {
  const { events = [], appearance = {} } = await chrome.storage.local.get(['events', 'appearance']);
  const prefix = appearance.dotIcons === false ? 'solid' : 'icon';
  await chrome.action.setIcon({ path: { 16: `icons/${prefix}-16.png`, 32: `icons/${prefix}-32.png`, 48: `icons/${prefix}-48.png` } });
  const { current } = currentAndNext(events);
  const e = current[0];
  await chrome.action.setBadgeBackgroundColor({ color: '#14695e' });
  await chrome.action.setBadgeText({ text: e ? String(Math.ceil((e.end - Date.now()) / 60000)) : '' });
  await chrome.action.setTitle({ title: e ? `${e.title} · ${e.room} · ${e.teacher} · ${Math.ceil((e.end - Date.now()) / 60000)} min left` : 'Afterbell — open your timetable' });
}
async function setup(details) {
  await chrome.alarms.create('clock', { periodInMinutes: 1 }); await update();
  if (details?.reason === 'install') {
    await chrome.tabs.create({ url: chrome.runtime.getURL('popup.html?view=tab&intro=1') });
    await chrome.storage.local.set({ introOpened: true });
  }
}
chrome.runtime.onInstalled.addListener(setup);
chrome.runtime.onStartup.addListener(setup);
chrome.alarms.onAlarm.addListener(a => { if (a.name === 'clock') update(); });
chrome.storage.onChanged.addListener(update);
setup();
