import { parseICS, currentAndNext, dayKey } from './calendar.js';
import { defaults, remainingText, clockState } from './appearance.js';
let appearance = { ...defaults }, preview = false, previewTime = 0;
const $ = id => document.getElementById(id);
let events = [], zone = 'Australia/Sydney', fileName = '';
const time = t => new Intl.DateTimeFormat('en-AU', { timeZone: zone, hour: 'numeric', minute: '2-digit' }).format(t);
const date = t => new Intl.DateTimeFormat('en-AU', { timeZone: zone, weekday: 'long', day: 'numeric', month: 'long' }).format(t);
function node(tag, text, cls) { const el = document.createElement(tag); el.textContent = text; if (cls) el.className = cls; return el; }
function countdown(ms) { const s = Math.max(0, Math.ceil(ms / 1000)); return `${Math.floor(s / 3600) ? Math.floor(s / 3600) + ':' : ''}${String(Math.floor(s / 60) % 60).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`; }
function card(e, active, now) {
  const box = node('div', '', 'hero');
  box.append(node('div', active ? 'IN CLASS NOW' : 'UP NEXT', 'eyebrow'), node('h2', e.title));
  const state = clockState(e, active, now, zone);
  box.dataset.clock = appearance.clockStyle;
  if (['pie', 'ring', 'analog'].includes(appearance.clockStyle)) {
    const dial = node('div', '', 'dial ' + appearance.clockStyle);
    dial.setAttribute('role', 'img');
    dial.setAttribute('aria-label', appearance.clockStyle === 'analog' ? 'Current school time: ' + time(now) : active ? Math.ceil(state.fraction * 100) + '% of class remaining' : 'Next class has not started');
    dial.style.setProperty('--remaining', (state.fraction ?? 0) * 360 + 'deg');
    if (appearance.clockStyle === 'analog') {
      for (let i = 1; i <= 12; i++) { const tick = node('span', String(i), 'numeral'); tick.style.left = (50 + 40 * Math.sin(i * Math.PI / 6)) + '%'; tick.style.top = (50 - 40 * Math.cos(i * Math.PI / 6)) + '%'; dial.append(tick); }
      for (const hand of ['hour','minute','second']) { const el = node('i', '', 'hand ' + hand); el.style.transform = 'rotate(' + state[hand] + 'deg)'; dial.append(el); }
      dial.append(node('b', '', 'hub'));
    } else dial.append(node('span', active ? Math.ceil(state.fraction * 100) + '%' : 'NEXT', 'dial-label'));
    box.append(dial);
    if (appearance.clockStyle === 'analog') box.append(node('p', 'School time · ' + time(now), 'meta'));
  }
  const duration = node('div', remainingText(state.remaining, appearance.units), 'count');
  duration.append(node('small', active ? 'remaining' : 'until class')); box.append(duration);
  box.append(node('p', `${time(e.start)} – ${time(e.end)}${dayKey(e.start, zone) !== dayKey(now, zone) ? ' · ' + date(e.start) : ''}`));
  box.append(node('div', [e.room, appearance.showTeacher ? e.teacher : ''].filter(Boolean).join(' · '), 'meta'));
  if (e.period && appearance.showPeriod) box.append(node('p', `Period ${e.period}`, 'meta'));
  if (active && appearance.showProgress) { const p = document.createElement('progress'); p.max = e.end - e.start; p.value = now - e.start; p.setAttribute('aria-label', 'Class progress'); box.append(p); }
  return box;
}
function render() {
  const now = Date.now();
  $('today').textContent = date(now); $('zoneLabel').textContent = zone;
  const demo = { title: 'Preview · Design and Technology', room: 'M3.10', teacher: 'Example teacher', period: '1', start: previewTime - 18 * 60000, end: previewTime + 36 * 60000 };
  const { current, next } = preview ? { current: [demo] } : currentAndNext(events, now);
  $('live').replaceChildren();
  if (current.length) { for (const e of current) $('live').append(card(e, true, now)); }
  else if (next) $('live').append(card(next, false, now));
  else $('live').append(node('div', events.length ? 'Your timetable has ended. Import a fresh Sentral export to keep tracking.' : 'Your day, on your terms. Open Settings to import your Sentral timetable.', 'empty'));
  $('classes').replaceChildren();
  const selected = events.filter(e => dayKey(e.start, zone) === $('date').value);
  for (const e of selected) {
    const active = e.start <= now && now < e.end;
    const row = node('div', '', 'class' + (active ? ' active' : ''));
    const times = node('div', time(e.start), 'times'); times.append(node('span', time(e.end)));
    const content = node('div', ''); const title = node('div', e.title, 'subject');
    if (active) title.append(node('span', 'NOW', 'pill'));
    content.append(title, node('div', [e.room, appearance.showTeacher ? e.teacher : ''].filter(Boolean).join(' · '), 'detail'), node('div', [e.period && appearance.showPeriod ? 'Period ' + e.period : '', e.code].filter(Boolean).join(' · '), 'detail'));
    row.append(times, content); $('classes').append(row);
  }
  if (!selected.length) $('classes').append(node('p', 'No classes scheduled for this date.', 'empty'));
}
$('file').addEventListener('change', async ev => {
  const file = ev.target.files[0]; if (!file) return;
  try {
    if (file.size > 8 * 1024 * 1024) throw new Error('Please choose an .ics file smaller than 8 MB.');
    const parsed = parseICS(await file.text());
    await chrome.storage.local.set({ events: parsed, fileName: file.name });
    events = parsed; fileName = file.name;
    $('source').textContent = `${fileName} · ${events.length} classes · ${date(events[0].start)} to ${date(events.at(-1).start)}`;
    $('message').textContent = `Imported ${events.length} classes.`; render();
  } catch (err) { $('message').textContent = err.message; }
  ev.target.value = '';
});
$('date').addEventListener('change', render);
$('zone').addEventListener('change', async () => { zone = $('zone').value; await chrome.storage.local.set({ zone }); $('date').value = dayKey(Date.now(), zone); render(); });
$('expand').addEventListener('click', () => chrome.tabs.create({ url: chrome.runtime.getURL('popup.html') }));
$('clear').addEventListener('click', async () => { await chrome.storage.local.remove(['events', 'fileName']); events = []; fileName = ''; $('source').textContent = ''; $('message').textContent = 'Timetable removed.'; render(); });
async function init() {
  const data = await chrome.storage.local.get(['events', 'zone', 'fileName', 'appearance', 'wallpaper']);
  appearance = { ...defaults, ...data.appearance };
  syncControls(); applyAppearance(); if (data.wallpaper) setWallpaper(data.wallpaper);
  events = data.events || []; zone = data.zone || zone; fileName = data.fileName || '';
  $('zone').value = zone; $('date').value = dayKey(Date.now(), zone);
  $('source').textContent = events.length ? `${fileName} · ${events.length} classes · ${date(events[0].start)} to ${date(events.at(-1).start)}` : '';
  $('settings').open = !events.length; render(); setInterval(render, 1000);
}
function syncControls() {
  for (const key of Object.keys(defaults)) { const el = $(key); if (el.type === 'checkbox') el.checked = appearance[key]; else el.value = appearance[key]; }
}
function applyAppearance() {
  document.body.dataset.theme = appearance.theme;
  document.body.dataset.background = appearance.background;
  document.body.classList.toggle('no-motion', !appearance.motion);
  const style = document.body.style;
  style.setProperty('--accent-custom', appearance.accent); style.setProperty('--base-custom', appearance.base); style.setProperty('--ink-custom', appearance.ink);
  style.setProperty('--timer-scale', appearance.scale / 100); style.setProperty('--dim', appearance.dim / 100);
  document.querySelector('.schedule').hidden = !appearance.showSchedule;
  const video = $('wallpaper');
  if (appearance.motion && appearance.background === 'upload') video.play().catch(() => {}); else video.pause();
}
async function saveAppearance() {
  try { await chrome.storage.local.set({ appearance }); $('appearanceMessage').textContent = 'Appearance saved.'; }
  catch { $('appearanceMessage').textContent = 'Could not save appearance. Try removing the uploaded background.'; }
}
for (const key of Object.keys(defaults)) $(key).addEventListener('input', () => {
  const el = $(key); appearance[key] = el.type === 'checkbox' ? el.checked : el.type === 'range' ? +el.value : el.value;
  if (['accent','base','ink'].includes(key)) { appearance.theme = 'custom'; $('theme').value = 'custom'; }
  applyAppearance(); render(); saveAppearance();
});
function setWallpaper(media) {
  $('wallpaper').removeAttribute('src'); $('backdrop').style.backgroundImage = '';
  if (media.type.startsWith('video/')) { $('wallpaper').src = media.url; $('wallpaper').muted = true; }
  else $('backdrop').style.backgroundImage = 'url("' + media.url + '")';
  applyAppearance();
}
$('media').addEventListener('change', async event => {
  const file = event.target.files[0]; if (!file) return;
  try {
    if (!['image/png','image/jpeg','image/gif','image/webp','video/mp4','video/webm'].includes(file.type)) throw Error('Choose a PNG, JPG, WebP, GIF, MP4 or WebM file.');
    if (file.size > 3 * 1024 * 1024) throw Error('Choose a background smaller than 3 MB.');
    const url = await new Promise((resolve, reject) => { const r = new FileReader(); r.onload = () => resolve(r.result); r.onerror = reject; r.readAsDataURL(file); });
    const media = { type: file.type, url };
    await chrome.storage.local.set({ wallpaper: media });
    appearance.background = 'upload'; syncControls(); setWallpaper(media); await saveAppearance();
  } catch (err) { $('appearanceMessage').textContent = err.message || 'Could not save background.'; }
  event.target.value = '';
});
$('removeBackground').addEventListener('click', async () => { await chrome.storage.local.remove('wallpaper'); $('wallpaper').removeAttribute('src'); $('backdrop').style.backgroundImage = ''; appearance.background = 'plain'; syncControls(); applyAppearance(); saveAppearance(); });
$('resetAppearance').addEventListener('click', () => { appearance = { ...defaults }; syncControls(); applyAppearance(); render(); saveAppearance(); });
$('preview').addEventListener('click', () => { preview = !preview; previewTime = Date.now(); $('preview').textContent = preview ? 'Exit preview' : 'Preview styles'; if (preview) $('settingsPanel').close(); $('appearanceMessage').textContent = preview ? 'Example class preview — your timetable is unchanged.' : ''; render(); });
$('openSettings').addEventListener('click', () => $('settingsPanel').showModal());
$('closeSettings').addEventListener('click', () => $('settingsPanel').close());
$('settingsPanel').addEventListener('click', event => { if (event.target === $('settingsPanel')) { const r = event.target.getBoundingClientRect(); if (event.clientX < r.left || event.clientX > r.right || event.clientY < r.top || event.clientY > r.bottom) event.target.close(); } });
init().catch(err => { $('message').textContent = 'Could not load timetable: ' + err.message; $('settings').open = true; $('settingsPanel').showModal(); });
