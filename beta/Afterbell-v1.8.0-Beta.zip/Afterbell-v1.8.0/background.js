import { currentAndNext } from './calendar.js';
import { readData } from './storage.js';
let updateRevision=0;
async function update() {
  const revision=++updateRevision;
  try {
  const { events = [], appearance = {} } = await readData();
  if(revision!==updateRevision)return;
  const prefix = appearance.dotIcons === false ? 'solid' : 'icon';
  await chrome.action.setIcon({ path: { 16: `icons/${prefix}-16.png`, 32: `icons/${prefix}-32.png`, 48: `icons/${prefix}-48.png` } });
  if(revision!==updateRevision)return;
  const { current } = currentAndNext(events);
  const e = current[0];
  await chrome.action.setBadgeBackgroundColor({ color: '#14695e' });
  if(revision!==updateRevision)return;
  await chrome.action.setBadgeText({ text: e ? String(Math.ceil((e.end - Date.now()) / 60000)) : '' });
  if(revision!==updateRevision)return;
  await chrome.action.setTitle({ title: e ? `${e.title} · ${e.room} · ${e.teacher} · ${Math.ceil((e.end - Date.now()) / 60000)} min left` : 'Afterbell — open your timetable' });
  } catch {
    if(revision!==updateRevision)return;
    await chrome.action.setBadgeText({text:'!'});
    await chrome.action.setTitle({title:'Afterbell — saved data could not be opened. Open Settings → Privacy to reset.'});
  }
}
async function setup(details) {
  await chrome.storage.local.setAccessLevel({accessLevel:'TRUSTED_CONTEXTS'});
  await chrome.alarms.create('clock', { periodInMinutes: 1 }); await update();
  if (details?.reason === 'install') {
    const previous=await chrome.storage.local.get(['introOpened','privateData','events','onboardingDismissed']);
    if(!previous.introOpened&&!previous.privateData&&!previous.events?.length&&!previous.onboardingDismissed){
      await chrome.storage.local.set({ introOpened: true });
      try { await chrome.tabs.create({ url: chrome.runtime.getURL('popup.html?view=tab&intro=1') }); }
      catch(err){await chrome.storage.local.remove('introOpened');throw err;}
    }
  }
}
chrome.runtime.onInstalled.addListener(setup);
chrome.runtime.onStartup.addListener(setup);
chrome.alarms.onAlarm.addListener(a => { if (a.name === 'clock') update(); });
chrome.storage.onChanged.addListener(update);
setup();


