# Afterbell v1.8.0 — Verification

228 checks passed: 137 real-extension regression checks, 12 lifecycle/concurrency checks, 13 icon/welcome checks, 7 first-run introduction checks, 23 strict calendar cases, 17 day-end boundary cases, 5 real-browser day-end states, and 14 privacy/storage checks. No uncaught browser exceptions were observed in the regression suite.

Test environment: Windows, isolated fresh Chromium 156.0.8078.4. The extension was loaded as a real Manifest V3 extension.

## This release

- Last class finished: Your day is done. No next-day countdown until exactly one hour before the next class. Long breaks have an idle message. Active classes and the timetable remain available.
- Local privacy policy and pre-import disclosure; Settings → Privacy includes explicit-confirmation deletion.
- AES-256-GCM encrypted timetable, filename and background, random IVs, locally stored non-extractable key, and migration from earlier plaintext extension data.
- Explicit self-only scripts/fonts/assets, no external connections, and trusted-context-only storage access. Only storage/alarms permissions remain.
- Shared bell master matches the website's canonical assets. Header/onboarding/toolbar use the same brand geometry, with an optical 16px variant and outline preference.

## Privacy tests

Verified legacy migration without losing displayed classes, absence of private plaintext fields in raw Chrome storage, decrypting after reload, fresh IVs, non-extractable key, unchanged permissions, blocked external requests, reachable policy, confirmation before deletion, corrupted-cipher recovery, removal of stored data and encryption database.

## Timing tests

Verified exact last-class end, next morning, overnight and weekend idle states, one millisecond outside the one-hour window, exact one-hour resumption, class start/end boundaries, overlapping classes and empty/expired exports.

## Regression coverage

Themes, six countdown styles, 14 fonts and dropdown consistency, colon dots, size/colour/visibility controls, backgrounds and reduced motion, decoded PNG/JPEG/WebP/GIF/MP4/WebM, corrupt/unsupported/oversized files, import/Apply/Cancel/reset/remove, real storage-quota failure, all time zones, midnight rollover, popup/tab/fullscreen navigation, help images, responsive widths, browser restart, delayed cancellation and concurrent saves.

This is tested behavior, not a guarantee of zero bugs across all browsers or legal/store approval. Public policy hosting and Developer Dashboard disclosures/certification remain publisher responsibilities; see PUBLICATION-NOTES.md.
