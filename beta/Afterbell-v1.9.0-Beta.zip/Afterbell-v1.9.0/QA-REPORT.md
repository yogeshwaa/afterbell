# Afterbell v1.9.0 — Reminder verification

293 checks passed across the existing regression suites and new reminder suites: 228 previous-feature checks, 36 notification/audio browser checks, 8 optional-permission/denial checks, and 21 scheduling/WAV checks. The main regression and reminder-browser suites observed no uncaught browser exceptions.

## Reminder coverage

Default two-minute lead; opt-in behavior; 0–60 minute validation; exact alarm timestamps; catch-up before a class; skipping old classes; overlap grouping; encrypted persistent deduplication history; native notification creation; hidden vs opted-in class details; all five generated WAV sounds decoded and played to completion in a real offscreen document; custom WAV upload/playback; encrypted audio; cancel/removal; corrupt/oversized/long audio; preview/test notifications; disabling cancels alarms and clears active class alerts.

## Permission-test boundary

The production manifest uses optional notifications/offscreen permissions and requests them only on user actions. The production opt-out state and denied-request branch were checked in isolation. Successful delivery/audio tests use the same extension source in a test copy with those permissions pre-granted, because the native Chrome permission confirmation bubble is not automated by this headless test. This fixture is not included in the release. Native permission confirmation and physical speaker/OS banner behavior remain user/platform-dependent.

## Existing coverage

137 real-extension regression checks plus calendar, day-end, privacy/deletion, first-run, icons, saved-state and concurrent-operation suites cover previously implemented features. Tests run in isolated Windows Chromium profiles; the production extension has no test dependencies.

## Timing and platform limits

Chrome must be running. Browser alarm throttling, sleep and OS Do Not Disturb/notification controls can delay or suppress delivery; reminders are not a guaranteed precise alarm. System sound follows OS volume. Custom audio is limited to 1 MB and 30 seconds. Notifications may be visible on the lock screen; detailed class information is off by default.

The bundled privacy policy and publication notes cover the new optional permissions, encrypted audio/history and local OS notification handling. Store publication still requires matching public policy and dashboard disclosures.
